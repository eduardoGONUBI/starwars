package com.example.zac.modules

class Users : ArrayList<UsersItem>()