package com.example.zac

import androidx.recyclerview.widget.RecyclerView
import android.view.ViewGroup
import android.view.LayoutInflater
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.zac.databinding.ItemLayoutBinding
import com.example.zac.modules.StarWarsCharacter

class RvAdapter(private val characterList: List<StarWarsCharacter>) : RecyclerView.Adapter<RvAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemLayoutBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemLayoutBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return characterList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = characterList[position]
        holder.binding.apply {
            tvCharacterName.text = currentItem.name
            tvVehicles.text = currentItem.vehicles.joinToString(", ")
            tvLanguage.text = currentItem.species.toString()

            // Load the language image using Glide
            if (currentItem.species.isNotEmpty()) {
                Glide.with(holder.itemView.context)
                    .load(currentItem.species[0]) // Use the first image URL from the list
                    .apply(RequestOptions().placeholder(R.drawable.placeholder).error(R.drawable.error))
                    .into(languageImageView)
            } else {
                languageImageView.setImageResource(R.drawable.placeholder)
            }
        }
    }
}
