package com.example.zac.modules

data class UsersItem(
    val body: String,
    val id: Int,
    val title: String,
    val userId: Int
)