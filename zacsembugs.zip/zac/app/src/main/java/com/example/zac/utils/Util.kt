package com.example.zac.utils

object Util {
    const val BASE = "https://https://jsonplaceholder.typicode.com/"
}